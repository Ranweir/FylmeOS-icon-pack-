# Flyme Icons (icon pack)

Source: flyme_OS_3_mtz (Lizenlia). 54 icons + 31 calendar date icons.

## Build
GitHub par repo banao, ye files push karo. Actions tab > Build APK > artifact `FlymeIcons-debug`.

## Use
ColorOS ka stock launcher icon pack support nahi karta. Nova / Lawnchair / Neo Launcher / Smart Launcher use karo.

## Missing icons theek karna
App kholo > "My apps". Jo app "Missing" hai, us par tap karo to component copy hota hai.
Usse `app/src/main/res/xml/appfilter.xml` aur `app/src/main/assets/appfilter.xml` dono me ek line add karo:
`<item component="ComponentInfo{pkg/activity}" drawable="ic_com_miui_gallery" />`
