package com.flymeos.iconpack;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.xmlpull.v1.XmlPullParser;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends Activity {

    private final Set<String> mapped = new HashSet<>();
    private ListView list;

    private static class Row {
        Drawable icon;
        String title;
        String sub;
        String copy;
        boolean ok = true;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        loadMapped();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = dp(16);
        root.setPadding(p, p, p, p);

        TextView how = new TextView(this);
        how.setText(R.string.how_to);
        how.setTextSize(13);
        root.addView(how);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        Button bIcons = new Button(this);
        bIcons.setText("Icons");
        Button bApps = new Button(this);
        bApps.setText("My apps");
        bar.addView(bIcons, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        bar.addView(bApps, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(bar);

        list = new ListView(this);
        root.addView(list, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        bIcons.setOnClickListener(v -> show(iconRows()));
        bApps.setOnClickListener(v -> show(appRows()));
        show(iconRows());
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private void loadMapped() {
        try {
            XmlPullParser x = getResources().getXml(R.xml.appfilter);
            int e = x.getEventType();
            while (e != XmlPullParser.END_DOCUMENT) {
                if (e == XmlPullParser.START_TAG && "item".equals(x.getName())) {
                    String c = x.getAttributeValue(null, "component");
                    if (c != null) mapped.add(c);
                }
                e = x.next();
            }
        } catch (Exception ignored) {
        }
    }

    private List<Row> iconRows() {
        List<Row> out = new ArrayList<>();
        for (Field f : R.drawable.class.getFields()) {
            String n = f.getName();
            if (!n.startsWith("ic_")) continue;
            try {
                Row r = new Row();
                r.icon = getResources().getDrawable(f.getInt(null), getTheme());
                r.title = n;
                r.sub = "";
                out.add(r);
            } catch (Exception ignored) {
            }
        }
        return out;
    }

    private List<Row> appRows() {
        PackageManager pm = getPackageManager();
        Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<Row> out = new ArrayList<>();
        for (ResolveInfo ri : pm.queryIntentActivities(i, 0)) {
            Row r = new Row();
            String comp = "ComponentInfo{" + ri.activityInfo.packageName + "/" + ri.activityInfo.name + "}";
            r.icon = ri.loadIcon(pm);
            r.title = String.valueOf(ri.loadLabel(pm));
            r.copy = comp;
            r.ok = mapped.contains(comp);
            r.sub = (r.ok ? "OK  " : "Missing  ") + ri.activityInfo.packageName + "/" + ri.activityInfo.name;
            out.add(r);
        }
        Collections.sort(out, (a, c) -> a.ok == c.ok ? a.title.compareToIgnoreCase(c.title) : (a.ok ? 1 : -1));
        return out;
    }

    private void show(final List<Row> rows) {
        list.setAdapter(new BaseAdapter() {
            @Override public int getCount() { return rows.size(); }
            @Override public Object getItem(int p) { return rows.get(p); }
            @Override public long getItemId(int p) { return p; }

            @Override
            public View getView(int p, View v, ViewGroup parent) {
                Row r = rows.get(p);
                LinearLayout row = new LinearLayout(MainActivity.this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(0, dp(6), 0, dp(6));
                ImageView iv = new ImageView(MainActivity.this);
                iv.setImageDrawable(r.icon);
                row.addView(iv, new LinearLayout.LayoutParams(dp(48), dp(48)));
                LinearLayout col = new LinearLayout(MainActivity.this);
                col.setOrientation(LinearLayout.VERTICAL);
                col.setPadding(dp(12), 0, 0, 0);
                TextView t = new TextView(MainActivity.this);
                t.setText(r.title);
                t.setTextSize(15);
                col.addView(t);
                if (r.sub != null && r.sub.length() > 0) {
                    TextView s = new TextView(MainActivity.this);
                    s.setText(r.sub);
                    s.setTextSize(11);
                    s.setTextColor(r.ok ? 0xFF2E7D32 : 0xFFC62828);
                    col.addView(s);
                }
                row.addView(col, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                return row;
            }
        });
        list.setOnItemClickListener((parent, view, pos, id) -> {
            Row r = rows.get(pos);
            if (r.copy == null) return;
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("component", r.copy));
            Toast.makeText(this, "Copied: " + r.copy, Toast.LENGTH_SHORT).show();
        });
    }
}
